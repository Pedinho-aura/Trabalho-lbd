/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.util;

import br.com.dao.UsuarioDAO;
import br.com.entidade.Usuario;
import java.security.GeneralSecurityException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Scanner;


/**
 *
 * @author tharlis.agrario
 */
public class InicializarUsuarios {
     public static void main(String[] args) {

        try (Scanner scanner = new Scanner(System.in)) {

            System.out.print("Login inicial: ");
            String login = scanner.nextLine().trim();

            System.out.print("Perfil (ADMINISTRADOR/ATENDENTE/CONSULTA): ");
            String perfil = scanner.nextLine().trim().toUpperCase();

            if (login.isBlank()) {
                throw new IllegalArgumentException("Login obrigatório.");
            }

            if (!Arrays.asList(
                    "ADMINISTRADOR", "ATENDENTE", "CONSULTA"
            ).contains(perfil)) {
                throw new IllegalArgumentException("Perfil inválido.");
            }

            System.out.print("Senha inicial: ");
            char[] senha = scanner.nextLine().toCharArray();

            try {
                if (senha.length < 5) {
                    throw new IllegalArgumentException(
                            "A senha deve ter pelo menos 12 caracteres.");
                }

                UsuarioDAO dao = new UsuarioDAO();

                if (dao.buscarPorLogin(login) != null) {
                    System.out.println("Este login já existe.");
                    return;
                }

                byte[] salt = SenhaUtil.gerarSalt();
                int iteracoes = SenhaUtil.getIteracoes();
                byte[] hash = SenhaUtil.gerarHash(
                        senha, salt, iteracoes);

                Usuario usuario = new Usuario();
                usuario.setLogin(login);
                usuario.setSenhaSalt(salt);
                usuario.setSenhaHash(hash);
                usuario.setIteracoes(iteracoes);
                usuario.setAtivo(true);
                usuario.setPerfil(perfil);

                if (dao.inserir(usuario)) {
                    System.out.println(
                            "Usuário cadastrado com sucesso!");
                }

                Arrays.fill(hash, (byte) 0);
                Arrays.fill(salt, (byte) 0);

            } finally {
                Arrays.fill(senha, '\0');
            }

        } catch (SQLException | GeneralSecurityException
                 | IllegalArgumentException e) {

            System.err.println(
                    "Não foi possível cadastrar o usuário: "
                    + e.getMessage());
        }
    }
}
