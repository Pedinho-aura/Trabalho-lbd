/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.util;

import br.com.entidade.Usuario;
import br.com.controle.AutenticacaoControle;
import java.security.GeneralSecurityException;
import java.sql.SQLException;
import java.util.Arrays;

/**
 *
 * @author tharlis.agrario
 */
public class TesteAutenticacao {
       public static void main(String[] args) {

        AutenticacaoControle controle =
                new AutenticacaoControle();

        String login = "usuario_teste_b5";

        char[] senhaCorreta = "Senh123".toCharArray();
        char[] senhaIncorreta = "SenhaErrada123".toCharArray();

        try {
            // Teste 1: autenticação com senha correta
            Usuario usuario = controle.autenticar(
                    login, senhaCorreta);

            System.out.println(
                    "Login correto: " + (usuario != null));

            if (usuario != null) {
                System.out.println(
                        "Perfil: " + usuario.getPerfil());
            }

            // Teste 2: autenticação com senha incorreta
            Usuario usuarioIncorreto = controle.autenticar(
                    login, senhaIncorreta);

            System.out.println(
                    "Login incorreto: "
                    + (usuarioIncorreto != null));

        } catch (SQLException | GeneralSecurityException e) {

            System.err.println(
                    "Falha no teste: " + e.getMessage());

        } finally {

            Arrays.fill(senhaCorreta, '\0');
            Arrays.fill(senhaIncorreta, '\0');
        }
    }
}
