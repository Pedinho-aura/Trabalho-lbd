/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.dao;

import br.com.entidade.RelatorioCliente;
import br.com.util.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author tharlis.agrario
 */
public class RelatorioDAO {
     public List<RelatorioCliente> listarConsolidadoPorCliente()
            throws SQLException {

        String sql =
            "SELECT * FROM vw_relatorio_consolidado_cliente " +
            "ORDER BY valor_total_pago DESC, cliente";

        List<RelatorioCliente> lista = new ArrayList<>();

        try (Connection conn = Conexao.abrirBanco();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                RelatorioCliente relatorio =
                        new RelatorioCliente();

                relatorio.setIdCliente(
                        rs.getInt("id_cliente"));

                relatorio.setCliente(
                        rs.getString("cliente"));

                relatorio.setQtdVeiculos(
                        rs.getInt("qtd_veiculos"));

                relatorio.setQtdDemandas(
                        rs.getInt("qtd_demandas"));

                relatorio.setQtdPendentes(
                        rs.getInt("qtd_pendentes"));

                relatorio.setQtdFinalizadas(
                        rs.getInt("qtd_finalizadas"));

                relatorio.setValorTotalPago(
                        rs.getBigDecimal("valor_total_pago"));

                relatorio.setTicketMedio(
                        rs.getBigDecimal("ticket_medio"));

                Timestamp data =
                        rs.getTimestamp("ultima_demanda");

                relatorio.setUltimaDemanda(
                        data != null
                            ? data.toLocalDateTime()
                            : null
                );

                lista.add(relatorio);
            }
        }

        return lista;
    }
}
