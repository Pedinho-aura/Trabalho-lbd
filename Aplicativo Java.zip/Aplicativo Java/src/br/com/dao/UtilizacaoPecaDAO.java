/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.dao;

import br.com.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author tharlis.agrario
 */
public class UtilizacaoPecaDAO {
    public void registrarUtilizacao(
            int idDemanda,
            int idPeca,
            int quantidade) throws SQLException {

        if (idDemanda <= 0 || idPeca <= 0 || quantidade <= 0) {
            throw new IllegalArgumentException(
                "Informe uma demanda, uma peça e uma quantidade válidas."
            );
        }

        String sqlEstoque =
            "UPDATE peca " +
            "SET qtd_estoque = qtd_estoque - ? " +
            "WHERE id_item = ? AND qtd_estoque >= ?";

        String sqlUtilizacao =
            "INSERT INTO utiliza (id_demanda, id_peca, quantidade) " +
            "VALUES (?, ?, ?) " +
            "ON DUPLICATE KEY UPDATE " +
            "quantidade = quantidade + ?";

        try (Connection conexao = Conexao.abrirBanco()) {

            conexao.setAutoCommit(false);

            try {
                // 1. Descontar a peça do estoque
                try (PreparedStatement ps =
                        conexao.prepareStatement(sqlEstoque)) {

                    ps.setInt(1, quantidade);
                    ps.setInt(2, idPeca);
                    ps.setInt(3, quantidade);

                    int linhas = ps.executeUpdate();

                    if (linhas != 1) {
                        throw new IllegalArgumentException(
                            "Peça inexistente ou estoque insuficiente."
                        );
                    }
                }

                // 2. Registrar ou incrementar a utilização
                try (PreparedStatement ps =
                        conexao.prepareStatement(sqlUtilizacao)) {

                    ps.setInt(1, idDemanda);
                    ps.setInt(2, idPeca);
                    ps.setInt(3, quantidade);
                    ps.setInt(4, quantidade);

                    ps.executeUpdate();
                }

                // 3. Confirmar ambas as alterações
                conexao.commit();

            } catch (SQLException | RuntimeException e) {

                // Desfazer todas as alterações
                try {
                    conexao.rollback();
                } catch (SQLException erroRollback) {
                    e.addSuppressed(erroRollback);
                }

                throw e;
            }
        }
    }
}
