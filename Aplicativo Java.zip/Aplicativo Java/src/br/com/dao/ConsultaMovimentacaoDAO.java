/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.dao;

import br.com.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author tharlis.agrario
 */
public class ConsultaMovimentacaoDAO {
      public List<Object[]> consultar(
            int categoria,
            LocalDateTime dataInicio,
            LocalDateTime dataFim,
            int minimoMovimentacoes) throws SQLException {

        List<Object[]> resultados = new ArrayList<>();

        String sql =
            "SELECT i.id_item AS Codigo_Peca, " +
            "i.id_categoria AS Codigo_Categoria, " +
            "COUNT(m.id_mov) AS Qtd_Movimentacoes, " +
            "MAX(COALESCE(m.data_saida, m.data_entrada)) " +
            "AS Ultima_Movimentacao " +
            "FROM item_estoque i " +
            "JOIN peca p ON p.id_item = i.id_item " +
            "JOIN movimentacao_estoque m ON m.id_item = i.id_item " +
            "WHERE i.id_categoria = ? " +
            "AND (m.data_entrada BETWEEN ? AND ? " +
            "OR m.data_saida BETWEEN ? AND ?) " +
            "GROUP BY i.id_item, i.id_categoria " +
            "HAVING COUNT(m.id_mov) >= ? " +
            "ORDER BY Qtd_Movimentacoes DESC";

        try (Connection conexao = Conexao.abrirBanco();
             PreparedStatement ps =
                     conexao.prepareStatement(sql)) {

            ps.setInt(1, categoria);
            ps.setTimestamp(2, Timestamp.valueOf(dataInicio));
            ps.setTimestamp(3, Timestamp.valueOf(dataFim));
            ps.setTimestamp(4, Timestamp.valueOf(dataInicio));
            ps.setTimestamp(5, Timestamp.valueOf(dataFim));
            ps.setInt(6, minimoMovimentacoes);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    int codigoPeca =
                            rs.getInt("Codigo_Peca");

                    int codigoCategoria =
                            rs.getInt("Codigo_Categoria");

                    int quantidade =
                            rs.getInt("Qtd_Movimentacoes");

                    Timestamp ultima =
                            rs.getTimestamp("Ultima_Movimentacao");

                    resultados.add(new Object[]{
                        codigoPeca,
                        codigoCategoria,
                        quantidade,
                        ultima
                    });
                }
            }
        }

        return resultados;
    }
}
