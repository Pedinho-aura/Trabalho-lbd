/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.dao;

import br.com.util.Conexao;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
       
/**
 *
 * @author tharlis.agrario
 */
public class ConsultaGastosDAO {
    public List<Object[]> consultar(
            String nome,
            LocalDateTime dataInicio,
            LocalDateTime dataFim) throws SQLException {

        List<Object[]> resultados = new ArrayList<>();

        String sql =
            "SELECT c.nome AS Nome_Cliente, " +
            "COUNT(DISTINCT d.id_demanda) AS Qtd_Ordens_Servico, " +
            "COALESCE(SUM(p.valor_pagamento), 0.00) AS Total_Gasto " +
            "FROM cliente c " +
            "JOIN veiculo v ON v.id_cliente = c.id_cliente " +
            "JOIN demanda d ON d.placa = v.placa " +
            "LEFT JOIN pagamento p ON p.id_demanda = d.id_demanda " +
            "WHERE c.nome LIKE ? " +
            "AND d.data_hora_abertura BETWEEN ? AND ? " +
            "GROUP BY c.id_cliente, c.nome " +
            "ORDER BY Total_Gasto DESC";

        try (Connection conexao = Conexao.abrirBanco();
             PreparedStatement ps =
                     conexao.prepareStatement(sql)) {

            ps.setString(1, "%" + nome + "%");
            ps.setTimestamp(2, Timestamp.valueOf(dataInicio));
            ps.setTimestamp(3, Timestamp.valueOf(dataFim));

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    String cliente =
                            rs.getString("Nome_Cliente");

                    int quantidade =
                            rs.getInt("Qtd_Ordens_Servico");

                    BigDecimal total =
                            rs.getBigDecimal("Total_Gasto");

                    resultados.add(new Object[]{
                        cliente,
                        quantidade,
                        total
                    });
                }
            }
        }

        return resultados;
    }
}
