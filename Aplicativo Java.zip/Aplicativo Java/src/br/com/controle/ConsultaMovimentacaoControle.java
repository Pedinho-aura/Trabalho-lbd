/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controle;

import br.com.dao.ConsultaMovimentacaoDAO;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * @author tharlis.agrario
 */
public class ConsultaMovimentacaoControle {
    private final ConsultaMovimentacaoDAO dao =
            new ConsultaMovimentacaoDAO();

    public List<Object[]> consultar(
            int categoria,
            LocalDateTime dataInicio,
            LocalDateTime dataFim,
            int minimoMovimentacoes) throws SQLException {

        if (categoria <= 0) {
            throw new IllegalArgumentException(
                    "Informe uma categoria válida.");
        }

        if (dataInicio == null || dataFim == null) {
            throw new IllegalArgumentException(
                    "Informe o período da consulta.");
        }

        if (dataInicio.isAfter(dataFim)) {
            throw new IllegalArgumentException(
                    "A data inicial não pode ser posterior à final.");
        }

        if (minimoMovimentacoes < 1) {
            throw new IllegalArgumentException(
                    "A quantidade mínima deve ser pelo menos 1.");
        }

        return dao.consultar(
                categoria,
                dataInicio,
                dataFim,
                minimoMovimentacoes
        );
    }
}
