/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controle;

import br.com.dao.ConsultaGastosDAO;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * @author tharlis.agrario
 */
public class ConsultaGastosControle {
      private final ConsultaGastosDAO dao =
            new ConsultaGastosDAO();

    public List<Object[]> consultar(
            String nome,
            LocalDateTime dataInicio,
            LocalDateTime dataFim) throws SQLException {

        if (dataInicio == null || dataFim == null) {
            throw new IllegalArgumentException(
                    "Informe o período da consulta.");
        }

        if (dataInicio.isAfter(dataFim)) {
            throw new IllegalArgumentException(
                    "A data inicial não pode ser posterior à final.");
        }

        return dao.consultar(
                nome == null ? "" : nome.trim(),
                dataInicio,
                dataFim
        );
    }
}
