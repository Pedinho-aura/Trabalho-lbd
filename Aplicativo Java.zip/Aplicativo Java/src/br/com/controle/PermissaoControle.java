/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controle;

import br.com.entidade.Usuario;

/**
 *
 * @author tharlis.agrario
 */
public class PermissaoControle {
     public enum Recurso {
        CLIENTE,
        VEICULO,
        FUNCIONARIO,
        DEMANDA,
        PAGAMENTO,
        CONSULTA_DEMANDAS,
        RELATORIO
    }

    public enum Acao {
        CONSULTAR,
        CADASTRAR,
        EDITAR,
        EXCLUIR
    }

    private final String perfil;

    public PermissaoControle(Usuario usuario) {

        if (usuario == null
                || !usuario.isAtivo()
                || usuario.getPerfil() == null) {

            throw new SecurityException(
                    "Usuário inválido ou não autenticado.");
        }

        this.perfil = usuario.getPerfil();
    }

    public boolean temPermissao(Recurso recurso, Acao acao) {

        if (recurso == null || acao == null) {
            return false;
        }

        switch (perfil) {

            case "ADMINISTRADOR":
                return true;

            case "ATENDENTE":
                return permissaoAtendente(recurso, acao);

            case "CONSULTA":
                return acao == Acao.CONSULTAR
                        && (recurso == Recurso.CLIENTE
                        || recurso == Recurso.VEICULO
                        || recurso == Recurso.FUNCIONARIO
                        || recurso == Recurso.DEMANDA
                        || recurso == Recurso.CONSULTA_DEMANDAS
                        || recurso == Recurso.PAGAMENTO
                        || recurso == Recurso.RELATORIO);

            default:
                return false;
        }
    }

    private boolean permissaoAtendente(
            Recurso recurso, Acao acao) {

            switch (recurso) {

            case CLIENTE:
            case VEICULO:
                return acao == Acao.CONSULTAR
                        || acao == Acao.CADASTRAR
                        || acao == Acao.EDITAR;

            case DEMANDA:
                return acao == Acao.CONSULTAR
                        || acao == Acao.CADASTRAR;

            case FUNCIONARIO:
            case PAGAMENTO:
            case CONSULTA_DEMANDAS:
            case RELATORIO:
                return acao == Acao.CONSULTAR;

            default:
                return false;
        }
    }

    public void exigirPermissao(Recurso recurso, Acao acao) {

        if (!temPermissao(recurso, acao)) {

            throw new SecurityException(
                    "Acesso negado. O perfil "
                    + perfil
                    + " não possui permissão para "
                    + acao
                    + " em "
                    + recurso + ".");
        }
    }
}
