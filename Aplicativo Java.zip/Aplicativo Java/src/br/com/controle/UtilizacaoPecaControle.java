/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controle;

import br.com.dao.UtilizacaoPecaDAO;
import java.sql.SQLException;

/**
 *
 * @author tharlis.agrario
 */
public class UtilizacaoPecaControle {
    private final UtilizacaoPecaDAO dao;

    public UtilizacaoPecaControle() {
        this.dao = new UtilizacaoPecaDAO();
    }

    public void registrarUtilizacao(
            int idDemanda,
            int idPeca,
            int quantidade) throws SQLException {

        // Validar demanda
        if (idDemanda <= 0) {
            throw new IllegalArgumentException(
                "Informe uma demanda válida."
            );
        }

        // Validar peça
        if (idPeca <= 0) {
            throw new IllegalArgumentException(
                "Informe uma peça válida."
            );
        }

        // Validar quantidade
        if (quantidade <= 0) {
            throw new IllegalArgumentException(
                "A quantidade deve ser maior que zero."
            );
        }

        // Executar a transação
        dao.registrarUtilizacao(
            idDemanda,
            idPeca,
            quantidade
        );
    }
}
