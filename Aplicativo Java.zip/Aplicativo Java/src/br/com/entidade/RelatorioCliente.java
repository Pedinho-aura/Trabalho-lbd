/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.entidade;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 *
 * @author tharlis.agrario
 */
public class RelatorioCliente {
    private int idCliente;
    private String cliente;
    private int qtdVeiculos;
    private int qtdDemandas;
    private int qtdPendentes;
    private int qtdFinalizadas;
    private BigDecimal valorTotalPago;
    private BigDecimal ticketMedio;
    private LocalDateTime ultimaDemanda;

    public RelatorioCliente() {
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public int getQtdVeiculos() {
        return qtdVeiculos;
    }

    public void setQtdVeiculos(int qtdVeiculos) {
        this.qtdVeiculos = qtdVeiculos;
    }

    public int getQtdDemandas() {
        return qtdDemandas;
    }

    public void setQtdDemandas(int qtdDemandas) {
        this.qtdDemandas = qtdDemandas;
    }

    public int getQtdPendentes() {
        return qtdPendentes;
    }

    public void setQtdPendentes(int qtdPendentes) {
        this.qtdPendentes = qtdPendentes;
    }

    public int getQtdFinalizadas() {
        return qtdFinalizadas;
    }

    public void setQtdFinalizadas(int qtdFinalizadas) {
        this.qtdFinalizadas = qtdFinalizadas;
    }

    public BigDecimal getValorTotalPago() {
        return valorTotalPago;
    }

    public void setValorTotalPago(BigDecimal valorTotalPago) {
        this.valorTotalPago = valorTotalPago;
    }

    public BigDecimal getTicketMedio() {
        return ticketMedio;
    }

    public void setTicketMedio(BigDecimal ticketMedio) {
        this.ticketMedio = ticketMedio;
    }

    public LocalDateTime getUltimaDemanda() {
        return ultimaDemanda;
    }

    public void setUltimaDemanda(LocalDateTime ultimaDemanda) {
        this.ultimaDemanda = ultimaDemanda;
    }
}
