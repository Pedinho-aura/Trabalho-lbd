## 1. Descrição do Domínio
A Oficina DF é uma empresa que faz a manutenção em todos os tipos de automóveis. Seu sistema tem o objetivo de obter mais organização e otimização de tempo.
O software cadastra os funcionários no sistema. Assim, o repositor fica responsável pelo controle de estoque, registrando as peças e equipamentos por categorias, situação (novo, seminovo etc.) e data de entrada/saída. O mecânico e seu atendente são identificados nas suas demandas. A cada serviço, as informações sobre o cliente, automóvel, peças, equipamentos, valor do serviço e forma de pagamento são registradas. 
O administrador tem o controle financeiro sobre os pagamentos, pois o sistema armazena as demandas com o status (pendente ou finalizado) e as datas sobre a entrada e entrega do automóvel.

## 2. Regras de Negócio

* **RN01:** Todo veículo cadastrado deve, obrigatoriamente, estar vinculado a um cliente.
* **RN02:** O status de uma demanda deve ser exclusivamente *Pendente* ou *Finalizado*, só podendo ser alterado para *Finalizado* após a quitação do pagamento.
* **RN03:** Toda demanda deve estar associada a um cliente e a um veículo cadastrados.
* **RN04:** Toda demanda deve ter pelo menos um funcionário (mecânico) responsável pelo atendimento.
* **RN05:** Toda movimentação de peças e equipamentos deve ter suas datas de entrada e saída obrigatoriamente registradas.
* **RN06:** A situação das peças (ex: novo, seminovo, recondicionado) deve ser obrigatoriamente preenchida no momento do cadastro.
* **RN07:** A data de saída do veículo deve ser, obrigatoriamente, igual ou posterior à sua data de entrada, sendo o registro da saída liberado após a quitação da demanda.
* **RN08:** Cada demanda deve registrar a data e a hora de abertura do serviço.
* **RN09:** Todo pagamento deve estar vinculado a uma demanda específica.
* **RN10:** Todo pagamento realizado deve ter sua data, valor e forma de pagamento obrigatoriamente informados.
* **RN11:** A inclusão e movimentação de itens no estoque é de responsabilidade exclusiva do repositor.
* **RN12:** A execução e a atualização do andamento dos serviços só podem ser atribuídas ao mecânico responsável pela demanda.
* **RN13:** O controle e a aprovação financeira das demandas são de responsabilidade exclusiva do administrador.
* **RN14:** O valor total de uma demanda deve ser maior ou igual a zero.
* **RN15:** O registro de peças em uma demanda exige que o item esteja disponível em estoque.
* **RN16:** Toda peça registrada no estoque obrigatoriamente deve possuir uma categoria vinculada.
* **RN17:** A quantidade de peças utilizada em uma demanda deve ser menor ou igual à quantidade disponível em estoque.
* **RN18:** Uma peça retirada do estoque não pode ser utilizada em outra demanda enquanto estiver reservada para um serviço.
* **RN19:** As formas de pagamento válidas devem ser restritas às opções aceitas pelo estabelecimento (ex: Dinheiro, PIX, Cartão de Crédito/Débito).
* **RN20:** Não é permitida a exclusão física de clientes ou veículos que possuam histórico de demandas registradas.
