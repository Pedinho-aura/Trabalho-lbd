-- B5 - Etapa 4: Usuário de teste

CREATE USER IF NOT EXISTS 'teste_consulta'@'localhost'
IDENTIFIED BY 'SenhaTemporaria_B5_2026!';

GRANT 'perfil_consulta'
TO 'teste_consulta'@'localhost';

SET DEFAULT ROLE 'perfil_consulta'
TO 'teste_consulta'@'localhost';

SHOW GRANTS FOR 'teste_consulta'@'localhost';

-- Deve funcionar
SELECT * FROM oficinadf.vw_consulta_demandas;

-- Deve falhar por falta de permissão
SELECT * FROM oficinadf.demanda;

SELECT USER(), CURRENT_USER(), CURRENT_ROLE();

SHOW GRANTS;