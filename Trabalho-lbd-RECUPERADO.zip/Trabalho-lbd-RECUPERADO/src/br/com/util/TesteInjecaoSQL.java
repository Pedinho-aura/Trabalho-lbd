/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author tharlis.agrario
 */
public class TesteInjecaoSQL {
     public static void main(String[] args) {

        String entrada = "' OR '1'='1' --";

        String sql = "SELECT id_cliente, nome "
                   + "FROM cliente WHERE nome = ?";

        try (Connection conexao = Conexao.abrirBanco();
             PreparedStatement ps = conexao.prepareStatement(sql)) {

            ps.setString(1, entrada);

            System.out.println("Entrada utilizada: " + entrada);
            System.out.println("Consulta parametrizada: " + sql);

            try (ResultSet rs = ps.executeQuery()) {

                int quantidade = 0;

                while (rs.next()) {
                    quantidade++;
                    System.out.println(
                        "Cliente encontrado: " + rs.getString("nome")
                    );
                }

                System.out.println(
                    "Quantidade de clientes encontrados: " + quantidade
                );

                System.out.println("Teste executado sem alterar dados.");
            }

        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
