/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.util;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 *
 * @author tharlis.agrario
 */
public class SenhaUtil {
      private static final int TAMANHO_SALT = 16;
    private static final int TAMANHO_HASH = 256;
    private static final int ITERACOES = 600000;

    private static final SecureRandom RANDOM = new SecureRandom();

    private SenhaUtil() {
    }

    public static byte[] gerarSalt() {
        byte[] salt = new byte[TAMANHO_SALT];
        RANDOM.nextBytes(salt);
        return salt;
    }

    public static int getIteracoes() {
        return ITERACOES;
    }

    public static byte[] gerarHash(
            char[] senha, byte[] salt, int iteracoes)
            throws GeneralSecurityException {

        if (senha == null || senha.length == 0) {
            throw new IllegalArgumentException("Senha inválida.");
        }

        if (salt == null || salt.length != TAMANHO_SALT) {
            throw new IllegalArgumentException("Salt inválido.");
        }

        if (iteracoes <= 0) {
            throw new IllegalArgumentException(
                    "Número de iterações inválido.");
        }

        PBEKeySpec especificacao = new PBEKeySpec(
                senha, salt, iteracoes, TAMANHO_HASH);

        try {
            SecretKeyFactory fabrica =
                    SecretKeyFactory.getInstance(
                            "PBKDF2WithHmacSHA256");

            return fabrica.generateSecret(
                    especificacao).getEncoded();

        } finally {
            especificacao.clearPassword();
        }
    }

    public static boolean verificarSenha(
            char[] senha,
            byte[] salt,
            byte[] hashArmazenado,
            int iteracoes)
            throws GeneralSecurityException {

        if (hashArmazenado == null
                || hashArmazenado.length != TAMANHO_HASH / 8) {
            return false;
        }

        byte[] hashCalculado =
                gerarHash(senha, salt, iteracoes);

        try {
            return MessageDigest.isEqual(
                    hashCalculado, hashArmazenado);
        } finally {
            Arrays.fill(hashCalculado, (byte) 0);
        }
    }
}
