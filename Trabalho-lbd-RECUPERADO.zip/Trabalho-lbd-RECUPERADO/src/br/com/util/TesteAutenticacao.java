/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.util;

import br.com.controle.AutenticacaoControle;
import java.security.GeneralSecurityException;
import java.sql.SQLException;
import java.util.Arrays;

/**
 *
 * @author tharlis.agrario
 */
public class TesteAutenticacao {
     public static void main(String[] args) {

        AutenticacaoControle controle =
                new AutenticacaoControle();

        char[] senhaCorreta = "TesteB5@2026!".toCharArray();
        char[] senhaIncorreta = "SenhaErrada123".toCharArray();

        try {
            boolean cadastrado = controle.cadastrar(
                    "usuario_teste_b5", senhaCorreta);

            System.out.println("Cadastro realizado: " + cadastrado);

            boolean loginCorreto = controle.autenticar(
                    "usuario_teste_b5", senhaCorreta);

            System.out.println("Login correto: " + loginCorreto);

            boolean loginIncorreto = controle.autenticar(
                    "usuario_teste_b5", senhaIncorreta);

            System.out.println("Login incorreto: " + loginIncorreto);

        } catch (SQLException | GeneralSecurityException e) {
            System.err.println(
                    "Falha no teste: " + e.getMessage());

        } finally {
            Arrays.fill(senhaCorreta, '\0');
            Arrays.fill(senhaIncorreta, '\0');
        }
    }
}
