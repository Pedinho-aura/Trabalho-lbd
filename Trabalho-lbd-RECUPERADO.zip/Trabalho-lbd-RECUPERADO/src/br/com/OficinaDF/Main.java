/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.OficinaDF;

import br.com.visao.LoginVisao;
import javax.swing.SwingUtilities;

/**
 *
 * @author tharlis.agrario
 */
public class Main {
//teste da silva
     public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            LoginVisao login = new LoginVisao();
            login.setLocationRelativeTo(null);
            login.setVisible(true);

        });
    }
}


