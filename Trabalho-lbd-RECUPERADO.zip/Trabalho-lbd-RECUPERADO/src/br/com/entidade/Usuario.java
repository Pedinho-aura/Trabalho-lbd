/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.entidade;


/**
 *
 * @author tharlis.agrario
 */
public class Usuario {
     private int idUsuario;
    private String login;
    private byte[] senhaHash;
    private byte[] senhaSalt;
    private int iteracoes;
    private boolean ativo;
    
    private String perfil;

    public Usuario() {
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public byte[] getSenhaHash() {
        return senhaHash == null
                ? null : senhaHash.clone();
    }

    public void setSenhaHash(byte[] senhaHash) {
        this.senhaHash = senhaHash == null
                ? null : senhaHash.clone();
    }

    public byte[] getSenhaSalt() {
        return senhaSalt == null
                ? null : senhaSalt.clone();
    }

    public void setSenhaSalt(byte[] senhaSalt) {
        this.senhaSalt = senhaSalt == null
                ? null : senhaSalt.clone();
    }

    public int getIteracoes() {
        return iteracoes;
    }

    public void setIteracoes(int iteracoes) {
        this.iteracoes = iteracoes;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }
    
    public String getPerfil() {
    return perfil;
}

public void setPerfil(String perfil) {
    this.perfil = perfil;
}
}
