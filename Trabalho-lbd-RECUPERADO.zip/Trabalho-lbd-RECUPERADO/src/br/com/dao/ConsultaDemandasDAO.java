/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.dao;

import br.com.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author tharlis.agrario
 */
public class ConsultaDemandasDAO {
    public DefaultTableModel listarDemandas()
            throws SQLException {

        String[] colunas = {
            "ID da Demanda",
            "Status",
            "Data e Hora de Abertura"
        };

        DefaultTableModel modelo =
                new DefaultTableModel(colunas, 0) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        String sql = "SELECT id_demanda, status, "
                + "data_hora_abertura "
                + "FROM vw_consulta_demandas "
                + "ORDER BY id_demanda";

        try (Connection conexao = Conexao.abrirBanco();
             PreparedStatement ps =
                     conexao.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Object[] linha = {
                    rs.getInt("id_demanda"),
                    rs.getString("status"),
                    rs.getTimestamp("data_hora_abertura")
                };

                modelo.addRow(linha);
            }
        }

        return modelo;
    }
}
