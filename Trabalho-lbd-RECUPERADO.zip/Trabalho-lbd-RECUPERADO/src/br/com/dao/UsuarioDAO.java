/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.dao;

import br.com.entidade.Usuario;
import br.com.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author tharlis.agrario
 */
public class UsuarioDAO {
       public boolean inserir(Usuario usuario) throws SQLException {

        String sql = "INSERT INTO usuario_sistema "
                + "(login, senha_hash, senha_salt, iteracoes, ativo) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (Connection conexao = Conexao.abrirBanco();
             PreparedStatement ps =
                     conexao.prepareStatement(sql)) {

            ps.setString(1, usuario.getLogin());
            ps.setBytes(2, usuario.getSenhaHash());
            ps.setBytes(3, usuario.getSenhaSalt());
            ps.setInt(4, usuario.getIteracoes());
            ps.setBoolean(5, usuario.isAtivo());

            return ps.executeUpdate() == 1;
        }
    }

    public Usuario buscarPorLogin(String login)
            throws SQLException {

        String sql = "SELECT id_usuario, login, senha_hash, "
                + "senha_salt, iteracoes, ativo "
                + "FROM usuario_sistema WHERE login = ?";

        try (Connection conexao = Conexao.abrirBanco();
             PreparedStatement ps =
                     conexao.prepareStatement(sql)) {

            ps.setString(1, login);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    Usuario usuario = new Usuario();

                    usuario.setIdUsuario(
                            rs.getInt("id_usuario"));

                    usuario.setLogin(
                            rs.getString("login"));

                    usuario.setSenhaHash(
                            rs.getBytes("senha_hash"));

                    usuario.setSenhaSalt(
                            rs.getBytes("senha_salt"));

                    usuario.setIteracoes(
                            rs.getInt("iteracoes"));

                    usuario.setAtivo(
                            rs.getBoolean("ativo"));

                    return usuario;
                }
            }
        }

        return null;
    }
}
