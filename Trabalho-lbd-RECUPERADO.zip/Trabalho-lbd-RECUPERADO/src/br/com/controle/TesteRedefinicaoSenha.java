/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controle;

import java.util.Arrays;
import javax.swing.JPasswordField;
import javax.swing.JOptionPane;

/**
 *
 * @author tharlis.agrario
 */
public class TesteRedefinicaoSenha {
    public static void main(String[] args) {

        JPasswordField campoSenha = new JPasswordField();

        int resposta = JOptionPane.showConfirmDialog(
                null,
                campoSenha,
                "Nova senha para teste_consulta_app",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (resposta != JOptionPane.OK_OPTION) {
            return;
        }

        char[] senha = campoSenha.getPassword();

        try {
            AutenticacaoControle controle =
                    new AutenticacaoControle();

            boolean atualizado = controle.redefinirSenha(
                    "usuario_teste_b5", senha); // APENAS MODIFICAR O NOME PARA REDEFINIÇÃO DE SENHA

            JOptionPane.showMessageDialog(
                    null,
                    atualizado
                            ? "Senha redefinida com sucesso!"
                            : "Usuário não encontrado."
            );

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Erro ao redefinir senha: " + e.getMessage()
            );

        } finally {
            Arrays.fill(senha, '\0');
            campoSenha.setText("");
        }
    }
}
