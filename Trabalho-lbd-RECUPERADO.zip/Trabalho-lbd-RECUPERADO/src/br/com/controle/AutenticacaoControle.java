/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controle;

import br.com.dao.UsuarioDAO;
import br.com.entidade.Usuario;
import br.com.util.SenhaUtil;
import java.security.GeneralSecurityException;
import java.sql.SQLException;
import java.util.Arrays;

/**
 *
 * @author tharlis.agrario
 */
public class AutenticacaoControle {

    private final UsuarioDAO usuarioDAO;

    public AutenticacaoControle() {
        this.usuarioDAO = new UsuarioDAO();
    }

    public boolean cadastrar(String login, char[] senha)
            throws SQLException, GeneralSecurityException {

        if (login == null || login.isBlank()) {
            throw new IllegalArgumentException(
                    "O login é obrigatório.");
        }

        if (senha == null || senha.length < 8) {
            throw new IllegalArgumentException(
                    "A senha deve conter pelo menos 8 caracteres.");
        }

        String loginNormalizado = login.trim();

        if (loginNormalizado.length() > 50) {
            throw new IllegalArgumentException(
                    "O login deve conter no máximo 50 caracteres.");
        }

        byte[] salt = SenhaUtil.gerarSalt();
        byte[] hash = null;

        try {
            hash = SenhaUtil.gerarHash(
                    senha, salt, SenhaUtil.getIteracoes());

            Usuario usuario = new Usuario();
            usuario.setLogin(loginNormalizado);
            usuario.setSenhaHash(hash);
            usuario.setSenhaSalt(salt);
            usuario.setIteracoes(SenhaUtil.getIteracoes());
            usuario.setAtivo(true);

            return usuarioDAO.inserir(usuario);

        } finally {
            if (hash != null) {
                Arrays.fill(hash, (byte) 0);
            }
            Arrays.fill(salt, (byte) 0);
        }
    }

    public Usuario autenticar(String login, char[] senha)
            throws SQLException, GeneralSecurityException {

        if (login == null || login.isBlank()
                || senha == null || senha.length == 0) {
            return null;
        }

        Usuario usuario = usuarioDAO.buscarPorLogin(
                login.trim());

        if (usuario == null || !usuario.isAtivo()) {
            return null;
        }

        boolean senhaValida = SenhaUtil.verificarSenha(
                senha,
                usuario.getSenhaSalt(),
                usuario.getSenhaHash(),
                usuario.getIteracoes()
        );

        if (!senhaValida) {
            return null;
        }

        // Não expor o hash e o salt à interface.
        usuario.setSenhaHash(null);
        usuario.setSenhaSalt(null);

        return usuario;
    }
        public boolean redefinirSenha(String login, char[] novaSenha)
            throws SQLException, GeneralSecurityException {

        if (login == null || login.isBlank()) {
            throw new IllegalArgumentException("Login obrigatório.");
        }

        if (novaSenha == null || novaSenha.length < 8) {
            throw new IllegalArgumentException(
                    "A senha deve conter pelo menos 8 caracteres.");
        }

        byte[] salt = SenhaUtil.gerarSalt();
        byte[] hash = null;

        try {
            hash = SenhaUtil.gerarHash(
                    novaSenha, salt, SenhaUtil.getIteracoes());

            return usuarioDAO.atualizarSenha(
                    login.trim(), hash, salt,
                    SenhaUtil.getIteracoes());

        } finally {
            if (hash != null) {
                Arrays.fill(hash, (byte) 0);
            }
            Arrays.fill(salt, (byte) 0);
        }
    }
}
