/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controle;

import br.com.entidade.Usuario;

/**
 *
 * @author tharlis.agrario
 */
public class PermissaoControle {
     public enum Recurso {
        CLIENTE,
        VEICULO,
        FUNCIONARIO,
        DEMANDA,
        PAGAMENTO,
        CONSULTA_DEMANDAS
    }

    public enum Acao {
        CONSULTAR,
        CADASTRAR,
        EDITAR,
        EXCLUIR
    }

    private final String perfil;

    public PermissaoControle(Usuario usuario) {

        if (usuario == null
                || !usuario.isAtivo()
                || usuario.getPerfil() == null) {

            throw new SecurityException(
                    "Usuário inválido ou não autenticado.");
        }

        this.perfil = usuario.getPerfil();
    }

    public boolean temPermissao(Recurso recurso, Acao acao) {

        if (recurso == null || acao == null) {
            return false;
        }

        switch (perfil) {

            case "ADMINISTRADOR":
                return true;

            case "ATENDENTE":
                return permissaoAtendente(recurso, acao);

            case "CONSULTA":
                return recurso == Recurso.CONSULTA_DEMANDAS
                        && acao == Acao.CONSULTAR;

            default:
                return false;
        }
    }

    private boolean permissaoAtendente(
            Recurso recurso, Acao acao) {

        switch (recurso) {

            case CLIENTE:
            case VEICULO:
                return acao == Acao.CONSULTAR
                        || acao == Acao.CADASTRAR
                        || acao == Acao.EDITAR;

            case DEMANDA:
                return acao == Acao.CONSULTAR
                        || acao == Acao.CADASTRAR;

            default:
                return false;
        }
    }

    public void exigirPermissao(Recurso recurso, Acao acao) {

        if (!temPermissao(recurso, acao)) {

            throw new SecurityException(
                    "Acesso negado. O perfil "
                    + perfil
                    + " não possui permissão para "
                    + acao
                    + " em "
                    + recurso + ".");
        }
    }
}
