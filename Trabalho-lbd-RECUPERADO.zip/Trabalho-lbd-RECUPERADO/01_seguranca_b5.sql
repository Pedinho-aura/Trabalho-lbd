
USE oficinadf;

-- 1. Criação dos perfis
CREATE ROLE IF NOT EXISTS 'perfil_administrador';
CREATE ROLE IF NOT EXISTS 'perfil_atendente';
CREATE ROLE IF NOT EXISTS 'perfil_consulta';

-- 2. Permissões do administrador
GRANT SELECT, INSERT, UPDATE, DELETE
ON oficinadf.*
TO 'perfil_administrador';

-- 3. Permissões do atendente
GRANT SELECT, INSERT, UPDATE
ON oficinadf.cliente
TO 'perfil_atendente';

GRANT SELECT, INSERT, UPDATE
ON oficinadf.veiculo
TO 'perfil_atendente';

GRANT SELECT, INSERT, UPDATE
ON oficinadf.demanda
TO 'perfil_atendente';

-- 4. Restrição explícita do atendente
REVOKE UPDATE
ON oficinadf.demanda
FROM 'perfil_atendente';

-- Verificação de perfis

SHOW GRANTS FOR 'perfil_administrador';
SHOW GRANTS FOR 'perfil_atendente';
SHOW GRANTS FOR 'perfil_consulta';

-- Criação de View

USE oficinadf;

CREATE OR REPLACE VIEW vw_consulta_demandas AS
SELECT
    id_demanda,
    status,
    data_hora_abertura
FROM demanda;

-- Permitir consulta apenas à visão
GRANT SELECT
ON oficinadf.vw_consulta_demandas
TO 'perfil_consulta';

-- Verificar permissões
SHOW GRANTS FOR 'perfil_consulta';

-- Testar a visão com a conta administrativa
SELECT * FROM vw_consulta_demandas;

-- Criação de usuários de teste: Usuário de teste

CREATE USER IF NOT EXISTS 'teste_consulta'@'localhost'
IDENTIFIED BY 'SenhaTemporaria_B5_2026!';

GRANT 'perfil_consulta'
TO 'teste_consulta'@'localhost';

SET DEFAULT ROLE 'perfil_consulta'
TO 'teste_consulta'@'localhost';

SHOW GRANTS FOR 'teste_consulta'@'localhost';

